# Basalt Proof Report

**Project:** demo-good
**Repository:** `/mnt/data/basalt-mvp-v1-full/examples/demo_good`
**Final Status:** `VERIFIED`
**Proof Score:** `98/100`
**Sandbox:** `temp`

## Checks

| Check | Status | Command | Duration | Message |
|---|---:|---|---:|---|
| install | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| build | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| lint | ✅ PASS | `python -m compileall .` | 1932 ms | Command passed. |
| typecheck | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| test | ✅ PASS | `python -m unittest discover -s tests` | 2045 ms | Command passed. |

## Security Findings

No blocking security findings detected by the MVP scanner.

## Mutation Testing

| File | Mutation | Result | Meaning |
|---|---|---|---|
| `app.py` | python_ast_logic_flip: `Add` → `Sub` | ✅ KILLED | Mutation killed: tests caught the injected bug. |

## AST-Anchored Graph Preview

- Files scanned: 2
- Symbols found: 5
- Edges found: 2
- Test files found: 1

Top symbols:
- `function` `add` in `app.py:1`
- `function` `is_adult` in `app.py:5`
- `class` `AppTests` in `tests/test_app.py:5`
- `function` `test_add` in `tests/test_app.py:6`
- `function` `test_is_adult_boundary` in `tests/test_app.py:9`

## Patch Suggestions

No fix suggestions required.

## Generated Artifacts

- **Patch Plan:** `/mnt/data/basalt-mvp-v1-full/examples/demo_good/.basalt/basalt-patch-plan.md` — PR-ready remediation plan
- **GitHub PR Description:** `/mnt/data/basalt-mvp-v1-full/examples/demo_good/.basalt/github-pr-description.md` — Copy/paste PR body for proof-hardening branch
- **Proof Report JSON:** `/mnt/data/basalt-mvp-v1-full/examples/demo_good/.basalt/proof-report.json` — Machine-readable proof evidence
- **Proof Report Markdown:** `/mnt/data/basalt-mvp-v1-full/examples/demo_good/.basalt/proof-report.md` — Human-readable proof report
- **Command Center Dashboard:** `/mnt/data/basalt-mvp-v1-full/examples/demo_good/.basalt/basalt-dashboard.html` — Browser-viewable MVP dashboard

## Verdict

Basalt marks this repository as **VERIFIED** based on configured proof checks.
