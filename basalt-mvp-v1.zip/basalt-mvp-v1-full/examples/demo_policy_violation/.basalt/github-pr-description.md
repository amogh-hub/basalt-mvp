# Basalt Proof Hardening PR

Project: `demo-policy-violation`
Current Basalt verdict: `BLOCKED_BY_POLICY`
Proof score: `36/100`

## Why this PR exists
Basalt found proof, policy, mutation, or security gaps that prevent the repo from being trusted as production-ready.

## Required changes
- [HIGH] Add a real test command: No test command is configured, so Basalt cannot prove behavior.
- [HIGH] Resolve policy-blocking finding: generic_api_key: Possible secret detected. Move secrets to environment variables or a secret vault. at `app.py:1`.
- [HIGH] Add a test suite mapped to behavior: Basalt did not find test files in the AST-backed project graph.

## Verification checklist
- [ ] `basalt verify .` returns `VERIFIED` or documented human review exceptions
- [ ] No blocking security findings remain
- [ ] Survived mutations are killed by improved tests or explicitly accepted with rationale
- [ ] Proof report attached to PR
