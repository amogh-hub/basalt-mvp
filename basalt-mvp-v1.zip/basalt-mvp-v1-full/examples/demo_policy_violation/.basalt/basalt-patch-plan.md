# Basalt Proof-to-PR Patch Plan

**Project:** demo-policy-violation
**Current verdict:** `BLOCKED_BY_POLICY`
**Proof score:** `36/100`

This is a PR-ready remediation plan generated from deterministic checks, security scan findings, mutation testing, and AST-backed project graph signals.

## Recommended branch

```bash
git checkout -b basalt/proof-hardening
```

## 1. Add a real test command

- **Severity:** HIGH
- **Category:** proof_strength
- **Problem:** No test command is configured, so Basalt cannot prove behavior.
- **Recommended change:** Add tests and configure `commands.test` in basalt.yaml.
- **Verify with:** `basalt verify .`

## 2. Resolve policy-blocking finding: generic_api_key

- **Severity:** HIGH
- **Category:** security_policy
- **Affected files:** `app.py`
- **Problem:** Possible secret detected. Move secrets to environment variables or a secret vault. at `app.py:1`.
- **Recommended change:** Remove the secret/risky operation from source. Use environment variables, a secret vault, or an expand-and-contract migration plan for data-destructive changes.
- **Verify with:** `basalt verify .`

## 3. Add a test suite mapped to behavior

- **Severity:** HIGH
- **Category:** proof_strength
- **Problem:** Basalt did not find test files in the AST-backed project graph.
- **Recommended change:** Create tests for core behavior and configure the test command in basalt.yaml.
- **Verify with:** `basalt verify .`

## PR acceptance rule

Do not merge until Basalt returns `VERIFIED`, or until every remaining high-risk item is explicitly approved by a human reviewer.
