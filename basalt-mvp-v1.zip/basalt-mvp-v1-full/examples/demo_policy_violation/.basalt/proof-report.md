# Basalt Proof Report

**Project:** demo-policy-violation
**Repository:** `/mnt/data/basalt-mvp-v1-full/examples/demo_policy_violation`
**Final Status:** `BLOCKED_BY_POLICY`
**Proof Score:** `36/100`
**Sandbox:** `temp`

## Checks

| Check | Status | Command | Duration | Message |
|---|---:|---|---:|---|
| install | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| build | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| lint | ✅ PASS | `python -m compileall .` | 2023 ms | Command passed. |
| typecheck | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| test | ⏭️ SKIPPED | — | 0 ms | No command configured. |

## Security Findings

| Level | File | Line | Rule | Message |
|---|---|---:|---|---|
| HIGH | `app.py` | 1 | generic_api_key | Possible secret detected. Move secrets to environment variables or a secret vault. |

## Mutation Testing

Mutation testing did not run or no mutation candidates were found.

## AST-Anchored Graph Preview

- Files scanned: 1
- Symbols found: 1
- Edges found: 0
- Test files found: 0

Top symbols:
- `function` `dangerous` in `app.py:3`

## Patch Suggestions

- **[HIGH] Add a real test command:** No test command is configured, so Basalt cannot prove behavior.
- **[HIGH] Resolve policy-blocking finding: generic_api_key:** Possible secret detected. Move secrets to environment variables or a secret vault. at `app.py:1`. Affected: `app.py`.
- **[HIGH] Add a test suite mapped to behavior:** Basalt did not find test files in the AST-backed project graph.

## Generated Artifacts

- **Patch Plan:** `/mnt/data/basalt-mvp-v1-full/examples/demo_policy_violation/.basalt/basalt-patch-plan.md` — PR-ready remediation plan
- **GitHub PR Description:** `/mnt/data/basalt-mvp-v1-full/examples/demo_policy_violation/.basalt/github-pr-description.md` — Copy/paste PR body for proof-hardening branch
- **Proof Report JSON:** `/mnt/data/basalt-mvp-v1-full/examples/demo_policy_violation/.basalt/proof-report.json` — Machine-readable proof evidence
- **Proof Report Markdown:** `/mnt/data/basalt-mvp-v1-full/examples/demo_policy_violation/.basalt/proof-report.md` — Human-readable proof report
- **Command Center Dashboard:** `/mnt/data/basalt-mvp-v1-full/examples/demo_policy_violation/.basalt/basalt-dashboard.html` — Browser-viewable MVP dashboard

## Verdict

Basalt marks this repository as **BLOCKED_BY_POLICY** due to a high-risk governance violation.
