# Basalt Proof Hardening PR

Project: `demo-weak`
Current Basalt verdict: `WEAK_PROOF`
Proof score: `78/100`

## Why this PR exists
Basalt found proof, policy, mutation, or security gaps that prevent the repo from being trusted as production-ready.

## Required changes
- [HIGH] Strengthen tests for app.py: A `python_ast_logic_flip` mutation survived in `app.py` (`GtE` -> `Gt`).

## Verification checklist
- [ ] `basalt verify .` returns `VERIFIED` or documented human review exceptions
- [ ] No blocking security findings remain
- [ ] Survived mutations are killed by improved tests or explicitly accepted with rationale
- [ ] Proof report attached to PR
