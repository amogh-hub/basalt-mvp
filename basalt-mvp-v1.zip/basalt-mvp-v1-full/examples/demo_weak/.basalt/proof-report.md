# Basalt Proof Report

**Project:** demo-weak
**Repository:** `/mnt/data/basalt-mvp-v1-full/examples/demo_weak`
**Final Status:** `WEAK_PROOF`
**Proof Score:** `78/100`
**Sandbox:** `temp`

## Checks

| Check | Status | Command | Duration | Message |
|---|---:|---|---:|---|
| install | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| build | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| lint | ✅ PASS | `python -m compileall .` | 2161 ms | Command passed. |
| typecheck | ⏭️ SKIPPED | — | 0 ms | No command configured. |
| test | ✅ PASS | `python -m unittest discover -s tests` | 2075 ms | Command passed. |

## Security Findings

No blocking security findings detected by the MVP scanner.

## Mutation Testing

| File | Mutation | Result | Meaning |
|---|---|---|---|
| `app.py` | python_ast_logic_flip: `GtE` → `Gt` | ⚠️ SURVIVED | Mutation survived: tests did not catch the injected bug. |

## AST-Anchored Graph Preview

- Files scanned: 2
- Symbols found: 3
- Edges found: 2
- Test files found: 1

Top symbols:
- `function` `is_adult` in `app.py:1`
- `class` `AppTests` in `tests/test_app.py:5`
- `function` `test_adult_happy_path_only` in `tests/test_app.py:6`

## Patch Suggestions

- **[HIGH] Strengthen tests for app.py:** A `python_ast_logic_flip` mutation survived in `app.py` (`GtE` -> `Gt`). Affected: `app.py`.

## Generated Artifacts

- **Patch Plan:** `/mnt/data/basalt-mvp-v1-full/examples/demo_weak/.basalt/basalt-patch-plan.md` — PR-ready remediation plan
- **GitHub PR Description:** `/mnt/data/basalt-mvp-v1-full/examples/demo_weak/.basalt/github-pr-description.md` — Copy/paste PR body for proof-hardening branch
- **Proof Report JSON:** `/mnt/data/basalt-mvp-v1-full/examples/demo_weak/.basalt/proof-report.json` — Machine-readable proof evidence
- **Proof Report Markdown:** `/mnt/data/basalt-mvp-v1-full/examples/demo_weak/.basalt/proof-report.md` — Human-readable proof report
- **Command Center Dashboard:** `/mnt/data/basalt-mvp-v1-full/examples/demo_weak/.basalt/basalt-dashboard.html` — Browser-viewable MVP dashboard

## Verdict

Basalt marks this repository as **WEAK_PROOF** because injected mutations survived. Strengthen tests before trusting the build.
