# Basalt Proof-to-PR Patch Plan

**Project:** demo-weak
**Current verdict:** `WEAK_PROOF`
**Proof score:** `78/100`

This is a PR-ready remediation plan generated from deterministic checks, security scan findings, mutation testing, and AST-backed project graph signals.

## Recommended branch

```bash
git checkout -b basalt/proof-hardening
```

## 1. Strengthen tests for app.py

- **Severity:** HIGH
- **Category:** mutation_testing
- **Affected files:** `app.py`
- **Problem:** A `python_ast_logic_flip` mutation survived in `app.py` (`GtE` -> `Gt`).
- **Recommended change:** Add tests that fail when this logic is changed. Focus on boundary cases, negative paths, auth/permission checks, expected error behavior, and schema/contract assertions.
- **Verify with:** `basalt verify .`

## PR acceptance rule

Do not merge until Basalt returns `VERIFIED`, or until every remaining high-risk item is explicitly approved by a human reviewer.
