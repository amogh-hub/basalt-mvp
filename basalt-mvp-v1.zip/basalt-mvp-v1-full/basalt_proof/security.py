from __future__ import annotations

import re
from pathlib import Path

from .models import SecurityFinding

SECRET_PATTERNS = [
    ("generic_api_key", re.compile(r"(?i)(api[_-]?key|secret|token|password)\s*[=:]\s*['\"][A-Za-z0-9_\-]{16,}['\"]")),
    ("aws_access_key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("private_key", re.compile(r"-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----")),
    ("jwt_like_token", re.compile(r"eyJ[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{10,}")),
]

DESTRUCTIVE_SQL_PATTERNS = [
    ("drop_table", re.compile(r"(?i)\bDROP\s+TABLE\b")),
    ("drop_column", re.compile(r"(?i)\bDROP\s+COLUMN\b")),
    ("truncate", re.compile(r"(?i)\bTRUNCATE\b")),
    ("destructive_alter", re.compile(r"(?i)\bALTER\s+TABLE\b.*\bDROP\b")),
]

AUTH_RISK_PATTERNS = [
    ("hardcoded_admin_true", re.compile(r"(?i)(is_admin|admin)\s*=\s*true")),
    ("auth_bypass_comment", re.compile(r"(?i)(todo|fixme).*\b(auth|permission|security|admin)\b")),
    ("debug_mode_true", re.compile(r"(?i)debug\s*=\s*true")),
    ("disable_tls_verify", re.compile(r"(?i)(verify\s*=\s*false|rejectUnauthorized\s*:\s*false)")),
]

TEXT_EXTENSIONS = {".py", ".js", ".jsx", ".ts", ".tsx", ".json", ".yaml", ".yml", ".env", ".sql", ".toml", ".md"}
SKIP_DIRS = {".git", "node_modules", ".venv", "venv", "__pycache__", "dist", "build", ".next", ".basalt"}


def _should_scan(path: Path) -> bool:
    if any(part in SKIP_DIRS for part in path.parts):
        return False
    return path.suffix.lower() in TEXT_EXTENSIONS or path.name.startswith(".env")


def scan_repo(repo_path: Path, block_destructive_migrations: bool = True) -> list[SecurityFinding]:
    findings: list[SecurityFinding] = []
    for path in repo_path.rglob("*"):
        if not path.is_file() or not _should_scan(path):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        relative = str(path.relative_to(repo_path))
        for line_number, line in enumerate(text.splitlines(), start=1):
            for rule, pattern in SECRET_PATTERNS:
                if pattern.search(line):
                    findings.append(SecurityFinding("HIGH", relative, line_number, rule, "Possible secret detected. Move secrets to environment variables or a secret vault."))
            if block_destructive_migrations and path.suffix.lower() == ".sql":
                for rule, pattern in DESTRUCTIVE_SQL_PATTERNS:
                    if pattern.search(line):
                        findings.append(SecurityFinding("HIGH", relative, line_number, rule, "Destructive SQL migration requires expand-and-contract approval."))
            for rule, pattern in AUTH_RISK_PATTERNS:
                if pattern.search(line):
                    findings.append(SecurityFinding("MEDIUM", relative, line_number, rule, "Possible auth/security risk requires review."))
    return findings
