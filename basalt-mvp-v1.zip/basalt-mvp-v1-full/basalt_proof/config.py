from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .models import BasaltConfig, CommandSpec


def _parse_scalar(value: str) -> Any:
    value = value.strip().strip('"').strip("'")
    if value.lower() == "true":
        return True
    if value.lower() == "false":
        return False
    if value.lower() in {"null", "none", "~"}:
        return None
    if value.isdigit():
        return int(value)
    return value


def _minimal_yaml_parse(text: str) -> dict[str, Any]:
    """Small YAML subset parser to keep the MVP dependency-free.

    Supports top-level sections with nested scalar key/value pairs.
    This intentionally avoids full YAML features so the MVP runs with zero deps.
    """
    result: dict[str, Any] = {}
    current_section: str | None = None

    for raw_line in text.splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        line = raw_line.rstrip()
        if not line.startswith((" ", "\t")) and line.endswith(":"):
            current_section = line[:-1].strip()
            result[current_section] = {}
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        parsed_value = _parse_scalar(value)
        if raw_line.startswith((" ", "\t")) and current_section:
            result.setdefault(current_section, {})[key] = parsed_value
        else:
            result[key] = parsed_value
            current_section = None
    return result


def load_raw_config(repo_path: Path) -> dict[str, Any]:
    for name in ("basalt.yaml", "basalt.yml"):
        path = repo_path / name
        if path.exists():
            return _minimal_yaml_parse(path.read_text(encoding="utf-8"))
    json_path = repo_path / "basalt.json"
    if json_path.exists():
        return json.loads(json_path.read_text(encoding="utf-8"))
    return {}


def infer_project_type(repo_path: Path) -> str:
    if (repo_path / "package.json").exists():
        return "node"
    if (repo_path / "pyproject.toml").exists() or (repo_path / "requirements.txt").exists() or list(repo_path.rglob("*.py")):
        return "python"
    return "unknown"


def _infer_node_commands(repo_path: Path) -> dict[str, str | None]:
    package_json = repo_path / "package.json"
    scripts: dict[str, str] = {}
    if package_json.exists():
        try:
            data = json.loads(package_json.read_text(encoding="utf-8"))
            scripts = data.get("scripts", {}) or {}
        except json.JSONDecodeError:
            scripts = {}
    package_manager = "npm"
    if (repo_path / "pnpm-lock.yaml").exists():
        package_manager = "pnpm"
    elif (repo_path / "yarn.lock").exists():
        package_manager = "yarn"
    run = "run" if package_manager in {"npm", "pnpm"} else ""
    return {
        "install": f"{package_manager} install" if package_json.exists() else None,
        "build": f"{package_manager} {run} build".strip() if "build" in scripts else None,
        "lint": f"{package_manager} {run} lint".strip() if "lint" in scripts else None,
        "typecheck": f"{package_manager} {run} typecheck".strip() if "typecheck" in scripts else None,
        "test": f"{package_manager} test" if "test" in scripts else None,
    }


def _infer_python_commands(repo_path: Path) -> dict[str, str | None]:
    has_tests = (repo_path / "tests").exists()
    return {
        "install": "python -m pip install -r requirements.txt" if (repo_path / "requirements.txt").exists() else None,
        "build": None,
        "lint": "python -m compileall .",
        "typecheck": None,
        "test": "python -m unittest discover -s tests" if has_tests else None,
    }


def infer_commands(repo_path: Path, project_type: str) -> dict[str, str | None]:
    if project_type == "node":
        return _infer_node_commands(repo_path)
    if project_type == "python":
        return _infer_python_commands(repo_path)
    return {"install": None, "build": None, "lint": None, "typecheck": None, "test": None}


def _command_spec(name: str, command: str | None, required: bool, timeout: int = 300) -> CommandSpec:
    return CommandSpec(name=name, command=command, required=required, timeout_seconds=timeout)


def load_config(repo_path: Path) -> BasaltConfig:
    raw = load_raw_config(repo_path)
    project = raw.get("project", {}) if isinstance(raw.get("project", {}), dict) else {}
    commands_raw = raw.get("commands", {}) if isinstance(raw.get("commands", {}), dict) else {}
    proof = raw.get("proof", {}) if isinstance(raw.get("proof", {}), dict) else {}
    policy = raw.get("policy", {}) if isinstance(raw.get("policy", {}), dict) else {}
    sandbox = raw.get("sandbox", {}) if isinstance(raw.get("sandbox", {}), dict) else {}

    project_name = str(project.get("name") or repo_path.name)
    project_type = str(project.get("type") or infer_project_type(repo_path))
    inferred = infer_commands(repo_path, project_type)
    merged_commands = {**inferred, **{k: v for k, v in commands_raw.items() if v not in ("", None)}}

    specs = [
        _command_spec("install", merged_commands.get("install"), required=False, timeout=900),
        _command_spec("build", merged_commands.get("build"), required=bool(proof.get("require_build", project_type == "node"))),
        _command_spec("lint", merged_commands.get("lint"), required=False),
        _command_spec("typecheck", merged_commands.get("typecheck"), required=project_type == "node"),
        _command_spec("test", merged_commands.get("test"), required=bool(proof.get("require_tests", True))),
    ]

    return BasaltConfig(
        project_name=project_name,
        project_type=project_type,
        commands=specs,
        mutation_sample=bool(proof.get("mutation_sample", True)),
        mutation_max=int(proof.get("mutation_max", 8)),
        security_scan=str(proof.get("security_scan", "basic")),
        max_test_failures=int(proof.get("max_test_failures", 0)),
        block_secrets=bool(policy.get("block_secrets", True)),
        block_destructive_migrations=bool(policy.get("block_destructive_migrations", True)),
        require_human_approval_for_deploy=bool(policy.get("require_human_approval_for_deploy", True)),
        generate_dashboard=bool(proof.get("dashboard", True)),
        generate_patch_plan=bool(proof.get("patch_plan", True)),
        generate_pr_pack=bool(proof.get("pr_pack", True)),
        sandbox=str(sandbox.get("mode") or "temp"),
        docker_image=str(sandbox.get("docker_image")) if sandbox.get("docker_image") else None,
    )


def render_default_config(project_name: str = "my-app", project_type: str = "python") -> str:
    if project_type == "node":
        commands = """  install: npm install\n  build: npm run build\n  lint: npm run lint\n  typecheck: npm run typecheck\n  test: npm test"""
        require_build = "true"
    else:
        commands = """  install: null\n  build: null\n  lint: python -m compileall .\n  typecheck: null\n  test: python -m unittest discover -s tests"""
        require_build = "false"
    return f"""project:\n  name: {project_name}\n  type: {project_type}\ncommands:\n{commands}\nproof:\n  require_build: {require_build}\n  require_tests: true\n  mutation_sample: true\n  mutation_max: 8\n  security_scan: basic\n  dashboard: true\n  patch_plan: true\n  pr_pack: true\npolicy:\n  block_secrets: true\n  block_destructive_migrations: true\n  require_human_approval_for_deploy: true\nsandbox:\n  mode: temp\n  docker_image: null\n"""
