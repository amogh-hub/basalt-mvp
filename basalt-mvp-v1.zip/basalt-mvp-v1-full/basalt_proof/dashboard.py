from __future__ import annotations

import html
import json
from pathlib import Path

from .models import ProofReport


def _esc(value: object) -> str:
    return html.escape(str(value))


def render_dashboard(report: ProofReport) -> str:
    data = json.dumps(report.to_dict(), indent=2)
    status_class = report.final_status.value.lower().replace("_", "-")
    checks_rows = "".join(
        f"<tr><td>{_esc(c.name)}</td><td><span class='pill'>{_esc(c.status.value)}</span></td><td><code>{_esc(c.command or '—')}</code></td><td>{_esc(c.duration_ms)} ms</td><td>{_esc(c.message)}</td></tr>"
        for c in report.checks
    )
    mutation_rows = "".join(
        f"<tr><td>{_esc(m.file)}</td><td>{_esc(m.mutation_type)}</td><td>{'SURVIVED' if m.survived else 'KILLED'}</td><td>{_esc(m.message)}</td></tr>"
        for m in report.mutations
    ) or "<tr><td colspan='4'>No mutation results.</td></tr>"
    security_rows = "".join(
        f"<tr><td>{_esc(f.level)}</td><td>{_esc(f.file)}:{_esc(f.line)}</td><td>{_esc(f.rule)}</td><td>{_esc(f.message)}</td></tr>"
        for f in report.security_findings
    ) or "<tr><td colspan='4'>No security findings.</td></tr>"
    suggestion_cards = "".join(
        f"<div class='card'><h3>{_esc(s.title)}</h3><p><b>{_esc(s.severity)} · {_esc(s.category)}</b></p><p>{_esc(s.problem)}</p><p>{_esc(s.recommended_change)}</p></div>"
        for s in report.fix_suggestions
    ) or "<div class='card'><h3>No patch suggestions</h3><p>This repo passed the configured MVP proof policy.</p></div>"

    symbols_preview = "".join(
        f"<li><code>{_esc(sym.kind)}</code> {_esc(sym.name)} <span>{_esc(sym.file)}:{_esc(sym.line)}</span></li>"
        for sym in report.knowledge_graph.symbols[:40]
    ) or "<li>No symbols found.</li>"

    artifacts = "".join(
        f"<li><b>{_esc(a.name)}</b>: <code>{_esc(a.path)}</code> — {_esc(a.purpose)}</li>"
        for a in report.artifacts
    ) or "<li>No extra artifacts.</li>"

    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Basalt Command Center — {html.escape(report.project_name)}</title>
<style>
:root {{ font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #101828; background: #f6f7fb; }}
body {{ margin: 0; }}
header {{ background: linear-gradient(135deg, #111827, #293447); color: white; padding: 30px 36px; }}
header h1 {{ margin: 0; font-size: 30px; letter-spacing: -.03em; }}
header p {{ opacity: .82; margin: 8px 0 0; }}
main {{ padding: 28px 36px 56px; max-width: 1240px; margin: auto; }}
.grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; }}
.metric, .section, .card {{ background: white; border: 1px solid #e5e7eb; border-radius: 16px; padding: 18px; box-shadow: 0 10px 24px rgba(16, 24, 40, .05); }}
.metric b {{ display: block; color: #667085; font-size: 13px; margin-bottom: 6px; }}
.metric span {{ font-size: 26px; font-weight: 750; }}
.status {{ display: inline-block; padding: 10px 14px; border-radius: 999px; background: #eef2ff; }}
.status.verified {{ background: #dcfce7; color: #14532d; }}
.status.weak-proof, .status.needs-human-review {{ background: #fef3c7; color: #78350f; }}
.status.not-verified, .status.blocked-by-policy {{ background: #fee2e2; color: #7f1d1d; }}
.section {{ margin-top: 18px; overflow-x: auto; }}
table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
th, td {{ border-bottom: 1px solid #eef2f7; padding: 10px; text-align: left; vertical-align: top; }}
code, pre {{ background: #f3f4f6; border-radius: 8px; padding: 2px 6px; }}
pre {{ padding: 16px; overflow-x: auto; max-height: 420px; }}
.pill {{ background: #eef2ff; border-radius: 999px; padding: 3px 8px; font-size: 12px; }}
.cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 14px; }}
li span {{ color: #667085; }}
.small {{ color: #667085; }}
</style>
</head>
<body>
<header>
  <h1>Basalt Command Center</h1>
  <p>Proof-to-PR MVP: verification, sandbox execution, mutation testing, AST graph, risk, and patch plan.</p>
</header>
<main>
  <div class="grid">
    <div class="metric"><b>Project</b><span>{_esc(report.project_name)}</span></div>
    <div class="metric"><b>Final Status</b><span class="status {status_class}">{_esc(report.final_status.value)}</span></div>
    <div class="metric"><b>Proof Score</b><span>{_esc(report.score)}/100</span></div>
    <div class="metric"><b>Sandbox</b><span>{_esc(report.sandbox)}</span></div>
  </div>

  <section class="section"><h2>Proof Checks</h2><table><thead><tr><th>Check</th><th>Status</th><th>Command</th><th>Duration</th><th>Message</th></tr></thead><tbody>{checks_rows}</tbody></table></section>
  <section class="section"><h2>Security / Policy Findings</h2><table><thead><tr><th>Level</th><th>Location</th><th>Rule</th><th>Message</th></tr></thead><tbody>{security_rows}</tbody></table></section>
  <section class="section"><h2>Mutation Testing</h2><table><thead><tr><th>File</th><th>Mutation</th><th>Result</th><th>Meaning</th></tr></thead><tbody>{mutation_rows}</tbody></table></section>
  <section class="section"><h2>Patch Plan</h2><div class="cards">{suggestion_cards}</div></section>
  <section class="section"><h2>AST-Anchored Project Graph Preview</h2><p>{_esc(report.knowledge_graph.files_scanned)} files scanned, {_esc(len(report.knowledge_graph.symbols))} symbols found, {_esc(len(report.knowledge_graph.edges))} edges found, {_esc(len(report.knowledge_graph.test_files))} test files.</p><ul>{symbols_preview}</ul></section>
  <section class="section"><h2>Generated Artifacts</h2><ul>{artifacts}</ul><p class="small">Use these artifacts as PR evidence and review material.</p></section>
  <section class="section"><h2>Raw JSON Evidence</h2><pre>{_esc(data)}</pre></section>
</main>
</body>
</html>"""


def write_dashboard(report: ProofReport, output_path: Path) -> None:
    output_path.write_text(render_dashboard(report), encoding="utf-8")
