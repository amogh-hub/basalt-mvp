from __future__ import annotations

import argparse
import json
import platform
import shutil
import sys
from pathlib import Path

from .config import infer_project_type, render_default_config
from .dashboard import write_dashboard
from .models import GeneratedArtifact
from .proof import verify_repo
from .report import write_json_report, write_markdown_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="basalt", description="Basalt Proof-to-PR MVP CLI")
    subparsers = parser.add_subparsers(dest="command")

    verify = subparsers.add_parser("verify", help="Verify a repository and generate proof reports, dashboard, and PR plan")
    verify.add_argument("repo", type=Path, help="Path to repository to verify")
    verify.add_argument("--out", type=Path, default=None, help="Output directory. Defaults to <repo>/.basalt")
    verify.add_argument("--sandbox", choices=["temp", "docker"], default=None, help="Execution sandbox mode. Defaults to basalt.yaml sandbox.mode or temp.")
    verify.add_argument("--keep-workspace", action="store_true", help="Keep temporary workspace for debugging")
    verify.add_argument("--no-dashboard", action="store_true", help="Do not generate Command Center HTML dashboard")

    init = subparsers.add_parser("init", help="Create a basalt.yaml in a repo")
    init.add_argument("repo", type=Path, nargs="?", default=Path("."), help="Repo path")
    init.add_argument("--type", choices=["python", "node"], default=None, help="Project type")
    init.add_argument("--name", default=None, help="Project name")
    init.add_argument("--force", action="store_true", help="Overwrite existing basalt.yaml")

    doctor = subparsers.add_parser("doctor", help="Check local Basalt MVP environment")
    doctor.add_argument("--json", action="store_true", help="Output JSON")

    explain = subparsers.add_parser("explain", help="Summarize an existing proof-report.json")
    explain.add_argument("report", type=Path, help="Path to proof-report.json")
    return parser


def run_verify(args: argparse.Namespace) -> int:
    repo = args.repo.resolve()
    out_dir = (args.out.resolve() if args.out else repo / ".basalt")
    out_dir.mkdir(parents=True, exist_ok=True)

    report = verify_repo(repo, keep_workspace=args.keep_workspace, sandbox_override=args.sandbox, output_dir=out_dir)

    json_path = out_dir / "proof-report.json"
    md_path = out_dir / "proof-report.md"
    write_json_report(report, json_path)
    write_markdown_report(report, md_path)
    report.artifacts.extend([
        GeneratedArtifact("Proof Report JSON", str(json_path), "Machine-readable proof evidence"),
        GeneratedArtifact("Proof Report Markdown", str(md_path), "Human-readable proof report"),
    ])

    dashboard_path = None
    if not args.no_dashboard:
        dashboard_path = out_dir / "basalt-dashboard.html"
        report.dashboard_path = str(dashboard_path)
        report.artifacts.append(GeneratedArtifact("Command Center Dashboard", str(dashboard_path), "Browser-viewable MVP dashboard"))
        # Re-write JSON/MD to include dashboard artifact metadata before dashboard embeds raw JSON.
        write_json_report(report, json_path)
        write_markdown_report(report, md_path)
        write_dashboard(report, dashboard_path)

    print("Basalt Proof-to-PR MVP")
    print(f"Project: {report.project_name}")
    print(f"Final Status: {report.final_status.value}")
    print(f"Proof Score: {report.score}/100")
    print("Artifacts written:")
    print(f"- {json_path}")
    print(f"- {md_path}")
    if report.patch_plan_path:
        print(f"- {report.patch_plan_path}")
    if dashboard_path:
        print(f"- {dashboard_path}")

    return 0 if report.final_status.value == "VERIFIED" else 1


def run_init(args: argparse.Namespace) -> int:
    repo = args.repo.resolve()
    repo.mkdir(parents=True, exist_ok=True)
    config_path = repo / "basalt.yaml"
    if config_path.exists() and not args.force:
        print(f"basalt.yaml already exists at {config_path}. Use --force to overwrite.", file=sys.stderr)
        return 1
    project_type = args.type or infer_project_type(repo)
    if project_type == "unknown":
        project_type = "python"
    project_name = args.name or repo.name
    config_path.write_text(render_default_config(project_name, project_type), encoding="utf-8")
    print(f"Created {config_path}")
    return 0


def run_doctor(args: argparse.Namespace) -> int:
    info = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "docker_available": shutil.which("docker") is not None,
        "git_available": shutil.which("git") is not None,
        "node_available": shutil.which("node") is not None,
        "npm_available": shutil.which("npm") is not None,
    }
    if args.json:
        print(json.dumps(info, indent=2))
    else:
        print("Basalt Doctor")
        for k, v in info.items():
            print(f"- {k}: {v}")
    return 0


def run_explain(args: argparse.Namespace) -> int:
    data = json.loads(args.report.read_text(encoding="utf-8"))
    print("Basalt Proof Report Summary")
    print(f"Project: {data.get('project_name')}")
    print(f"Status: {data.get('final_status')}")
    print(f"Score: {data.get('score')}/100")
    print(f"Checks: {len(data.get('checks', []))}")
    print(f"Security findings: {len(data.get('security_findings', []))}")
    print(f"Mutations: {len(data.get('mutations', []))}")
    suggestions = data.get("fix_suggestions", [])
    if suggestions:
        print("Top actions:")
        for s in suggestions[:5]:
            print(f"- [{s.get('severity')}] {s.get('title')}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "verify":
        return run_verify(args)
    if args.command == "init":
        return run_init(args)
    if args.command == "doctor":
        return run_doctor(args)
    if args.command == "explain":
        return run_explain(args)
    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
