# Basalt Proof-to-PR MVP v1

Basalt is a proof-first, prevention-first AI software factory. This MVP does **not** try to be a full autonomous app generator yet. It proves the core wedge first:

> Give Basalt a repo. It verifies whether the repo is trustworthy, finds weak proof, creates evidence, and produces a PR-ready remediation plan.

## What this MVP includes

- `basalt verify <repo>` CLI
- `basalt init <repo>` config generator
- `basalt doctor` environment check
- Safe temp-workspace sandbox by default
- Optional Docker execution mode via `sandbox.mode: docker` or `--sandbox docker`
- Build/lint/typecheck/test command runner with MVP command allowlist
- Basic security scanner for secrets, destructive SQL, auth bypass signals, and risky debug settings
- Mutation testing sample to detect weak tests
- AST-backed project graph preview for Python and JS/TS files
- Proof score and final verdict
- `proof-report.json`
- `proof-report.md`
- `basalt-dashboard.html` Command Center MVP
- `basalt-patch-plan.md` Proof-to-PR remediation plan
- `github-pr-description.md` PR body template

## Install locally

```bash
python3.14 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
pip install -e .
```

Python 3.10+ works. You tested successfully with Python 3.14.

## Run demos

Good repo:

```bash
basalt verify examples/demo_good
```

Expected: `VERIFIED`

Weak proof repo:

```bash
basalt verify examples/demo_weak
```

Expected: `WEAK_PROOF`

Policy violation repo:

```bash
basalt verify examples/demo_policy_violation
```

Expected: `BLOCKED_BY_POLICY`

## Output artifacts

By default, Basalt writes artifacts to:

```text
<repo>/.basalt/
  proof-report.json
  proof-report.md
  basalt-dashboard.html
  basalt-patch-plan.md
  github-pr-description.md
```

Open the dashboard:

```bash
open examples/demo_weak/.basalt/basalt-dashboard.html
```

## Try on your own repo

```bash
cd /path/to/your/repo
basalt init . --type python
basalt verify .
```

For Node projects:

```bash
basalt init . --type node
basalt verify .
```

Edit `basalt.yaml` if your commands differ.

## MVP positioning

Cursor helps developers write code faster.
Emergent helps generate apps quickly.
Antigravity focuses on agentic development workflows.
Basalt MVP starts with the missing layer: **proof that software is actually trustworthy enough to ship.**

## Current limits

This is a strong MVP, not the final Basalt vision. It does not yet include the full Product Brain, 12-agent autonomous builder, production deployment, complete UI builder, enterprise connectors, or long-term maintenance mode. Those come after the proof engine is trusted.

## Next build after this MVP

1. Add GitHub API integration to open real PRs.
2. Add stronger language-specific mutation engines.
3. Add real Semgrep/npm-audit/pip-audit integrations.
4. Add single-agent safe fix loop.
5. Add richer Command Center web app.
